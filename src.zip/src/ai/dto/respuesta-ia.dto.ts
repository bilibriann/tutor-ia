export class RespuestaIaDto {
  respuesta: string;
  tokens: number;
}
