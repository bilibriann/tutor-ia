export interface JWTPayload {
  sub: string; // id o rut
  user: string; // username
  rol: 'admin' | 'usuario';
  iat?: number;
  exp?: number;
}
