import type { Rol } from '../auth/types/rol.enum';
import type { JWTPayload } from '../auth/interface/jwt_payload.interface';

declare global {
  namespace Express {
    interface Request {
      usuarioPayload?: JWTPayload;
      usuario?: {
        id: string;
        username: string;
        rol: Rol;
      };
    }
  }
}

export {};
