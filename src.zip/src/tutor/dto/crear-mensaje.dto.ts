export class CrearMensajeDto {
  mensaje!: string;
}
