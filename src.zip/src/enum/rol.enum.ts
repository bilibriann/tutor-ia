export enum Roles {
  ADMIN = 'admin',
  USUARIO = 'usuario',
}
