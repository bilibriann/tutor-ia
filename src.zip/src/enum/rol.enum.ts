export enum Rol {
  ADMIN = 'admin',
  USUARIO = 'usuario',
}
